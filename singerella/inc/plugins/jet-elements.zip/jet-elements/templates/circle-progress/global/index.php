<?php
/**
 * Circle progress template
 */
$position = $this->get_settings( 'content_position' );
$this->add_render_attribute( 'circle-wrap', array(
	'class'         => 'circle-progress-wrap position-' . $position,
	'data-duration' => $this->get_settings( 'duration' ),
) );

?>
<div <?php echo $this->get_render_attribute_string( 'circle-wrap' ); ?>>
	<?php include $this->__get_global_template( 'circle' ); ?>
	<?php include $this->__get_global_template( 'counter' ); ?>
</div>
<?php
/**
 * Advanced carousel template
 */
?>
<div class="adv-carousel-wrap">
	<?php $this->__get_global_looped_template( 'items', 'items_list' ); ?>
</div>
<?php
/**
 * Loop item template
 */
?>
<div class="adv-carousel__item"><?php
	echo $this->__loop_item( array( 'item_image', 'url' ), '<img src="%s" alt="" class="adv-carousel__item-img">' );
	echo '<div class="adv-carousel__contnet">';
		echo $this->__loop_item( array( 'item_title' ), '<h5 class="adv-carousel__item-title">%s</h5>' );
		echo $this->__loop_item( array( 'item_text' ), '<div class="adv-carousel__item-text">%s</div>' );
	echo '</div>';
?></div>